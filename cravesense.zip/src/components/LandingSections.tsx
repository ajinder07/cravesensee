import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, TrendingUp, Sparkles, MapPin, Clock, Star, 
  ChevronDown, Search, ArrowRight, Heart, ShoppingBag, 
  Wallet, Mic, Zap, ShieldCheck
} from 'lucide-react';

const STATS = [
  { label: 'AI Recommendations', value: '10,000+' },
  { label: 'Restaurants', value: '500+' },
  { label: 'Delivery Platforms', value: '8+' },
  { label: 'Saved by Users', value: '₹1M+' }
];

const STEPS = [
  { step: '01', title: 'Tell us your mood.', desc: 'Type or speak how you are feeling today.' },
  { step: '02', title: 'AI understands your cravings.', desc: 'Our AI analyzes your mood and matches it with food.' },
  { step: '03', title: 'Compare prices instantly.', desc: 'See online delivery vs. offline restaurant prices.' },
  { step: '04', title: 'Choose the smartest meal.', desc: 'Save money and enjoy exactly what you crave.' }
];

const FEATURES = [
  { title: 'AI Mood Detection', icon: <Brain className="w-6 h-6 text-brand-coral" /> },
  { title: 'Personalized Food Recommendations', icon: <Sparkles className="w-6 h-6 text-brand-coral" /> },
  { title: 'Smart Price Comparison', icon: <TrendingUp className="w-6 h-6 text-brand-coral" /> },
  { title: 'Online vs Offline Savings', icon: <Wallet className="w-6 h-6 text-brand-coral" /> },
  { title: 'Restaurant Discovery', icon: <Search className="w-6 h-6 text-brand-coral" /> },
  { title: 'Budget-Friendly Suggestions', icon: <ShieldCheck className="w-6 h-6 text-brand-coral" /> },
  { title: 'Student Discounts', icon: <Zap className="w-6 h-6 text-brand-coral" /> },
  { title: 'Voice Mood Input', icon: <Mic className="w-6 h-6 text-brand-coral" /> },
  { title: 'Favorites', icon: <Heart className="w-6 h-6 text-brand-coral" /> },
  { title: 'AI Food Assistant', icon: <Brain className="w-6 h-6 text-brand-coral" /> }
];

const CATEGORIES = [
  { name: 'Pizza', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80' },
  { name: 'Burger', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80' },
  { name: 'Biryani', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&q=80' },
  { name: 'Chinese', image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=500&q=80' },
  { name: 'South Indian', image: 'https://images.unsplash.com/photo-1610192131652-32b005188fcc?w=500&q=80' },
  { name: 'Italian', image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=500&q=80' },
  { name: 'Desserts', image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500&q=80' },
  { name: 'Coffee', image: 'https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=500&q=80' },
  { name: 'Healthy Meals', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80' },
  { name: 'Street Food', image: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=500&q=80' }
];

const RESTAURANTS = [
  { name: 'The Rustic Spatula', cuisine: 'Italian', rating: 4.8, time: '30 mins', distance: '2.5 km', price: '₹₹₹', popular: 'Truffle Pasta' },
  { name: 'Spice Route', cuisine: 'North Indian', rating: 4.5, time: '40 mins', distance: '4.0 km', price: '₹₹', popular: 'Butter Chicken' },
  { name: 'Green Bowl', cuisine: 'Healthy', rating: 4.9, time: '20 mins', distance: '1.2 km', price: '₹₹', popular: 'Quinoa Salad' }
];

const FAQS = [
  { q: 'How does CraveSense detect my mood?', a: 'CraveSense uses advanced natural language processing AI to analyze the keywords, sentiment, and tone of your text or voice input to match it with scientifically and culturally backed food associations.' },
  { q: 'Which food delivery platforms are compared?', a: 'Currently, we aggregate and compare prices from major platforms including Zomato, Swiggy, Uber Eats, and MagicPin, ensuring you get a comprehensive view.' },
  { q: 'Can I compare dine-in prices?', a: 'Yes! Our database includes the standard offline menu prices for restaurants so you can see exactly how much you are paying in delivery markups and fees.' },
  { q: 'Is CraveSense free?', a: 'Yes, using CraveSense to find food and compare prices is 100% free for users.' },
  { q: 'How accurate are the recommendations?', a: 'Our AI has a 95%+ satisfaction rate. By considering your mood, location, and budget, we provide highly contextual and personalized recommendations.' }
];

const TESTIMONIALS = [
  { text: "I used to spend 30 minutes just deciding what to eat. Now I tell CraveSense I'm stressed, and it finds the best comfort food AND the cheapest app to order it from.", author: "Priya S.", role: "Product Manager" },
  { text: "The offline vs online price comparison is eye-opening. I saved ₹250 on a single order by realizing it was cheaper to pick it up on my way home.", author: "Rahul M.", role: "Student" },
  { text: "The voice feature is magic. I just vent to the app after work and it suggests exactly what I didn't know I was craving.", author: "Anita K.", role: "Designer" }
];

export function LandingSections({ onGetStarted }: { onGetStarted: () => void }) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="bg-brand-beige text-brand-dark pt-20">
      
      {/* 1. Trusted by Food Lovers (Stats) */}
      <section className="py-16 border-t border-b border-gray-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {STATS.map((stat, idx) => (
              <div key={idx} className="flex flex-col">
                <span className="font-heading text-4xl md:text-5xl text-brand-coral font-bold mb-2">{stat.value}</span>
                <span className="text-gray-500 font-bold text-sm uppercase tracking-wider">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. How It Works */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-5xl text-brand-dark uppercase tracking-wide mb-4">How It Works</h2>
          <p className="text-xl text-gray-600 font-medium max-w-2xl mx-auto">Four simple steps to your perfect meal.</p>
        </div>
        <div className="grid md:grid-cols-4 gap-8 relative">
          <div className="hidden md:block absolute top-12 left-[10%] right-[10%] h-0.5 bg-gray-200 z-0"></div>
          {STEPS.map((step, idx) => (
            <div key={idx} className="relative z-10 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-white border border-gray-200 flex items-center justify-center font-heading text-3xl text-brand-coral shadow-sm mb-6">
                {step.step}
              </div>
              <h3 className="text-xl font-bold mb-2">{step.title}</h3>
              <p className="text-gray-600 font-medium">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Interactive Demo & Price Comparison */}
      <section className="py-24 bg-brand-dark text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-brand-coral/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-heading text-4xl md:text-5xl uppercase tracking-wide mb-6">See It In Action</h2>
              <p className="text-xl text-gray-300 font-medium mb-10 leading-relaxed">
                Watch how CraveSense analyzes a simple mood input, curates the perfect food, and instantly finds the most cost-effective way to get it to your door.
              </p>
              
              {/* Fake Comparison Table inside the text area */}
              <div className="bg-white/10 rounded-2xl p-6 backdrop-blur-sm border border-white/10 mb-8 overflow-x-auto">
                <h4 className="text-sm font-bold text-brand-coral uppercase tracking-wider mb-4">Live Price Comparison</h4>
                <table className="w-full text-left min-w-[500px]">
                  <thead>
                    <tr className="border-b border-white/20 text-gray-400 text-sm">
                      <th className="pb-3 font-medium">Platform</th>
                      <th className="pb-3 font-medium">Price</th>
                      <th className="pb-3 font-medium">Fees</th>
                      <th className="pb-3 font-medium text-brand-green">Total</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm font-bold">
                    <tr className="border-b border-white/10">
                      <td className="py-4">Offline (Dine-in)</td>
                      <td>₹220</td>
                      <td>₹0</td>
                      <td className="text-brand-green text-lg">₹220</td>
                    </tr>
                    <tr className="border-b border-white/10">
                      <td className="py-4">Zomato</td>
                      <td>₹240</td>
                      <td>₹35</td>
                      <td>₹275</td>
                    </tr>
                    <tr>
                      <td className="py-4 text-brand-coral">Swiggy</td>
                      <td className="text-brand-coral">₹240</td>
                      <td className="text-brand-coral">₹55</td>
                      <td className="text-brand-coral">₹295</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Interactive Demo UI Mockup */}
            <div className="bg-brand-beige rounded-[2.5rem] p-6 shadow-2xl text-brand-dark transform lg:rotate-2">
              <div className="bg-white rounded-[2rem] p-6 shadow-sm mb-4">
                <div className="flex gap-4 items-center mb-6">
                  <div className="w-10 h-10 rounded-full bg-brand-coral flex items-center justify-center text-white font-bold">U</div>
                  <div className="bg-gray-100 rounded-2xl p-4 rounded-tl-none font-medium text-gray-700">
                    "I had a really stressful day at work."
                  </div>
                </div>
                <div className="flex gap-4 items-center">
                  <div className="w-10 h-10 rounded-full bg-brand-dark flex items-center justify-center text-white"><Sparkles className="w-5 h-5"/></div>
                  <div className="bg-brand-beige/50 border border-brand-beige rounded-2xl p-4 rounded-tl-none flex-grow">
                    <p className="font-bold text-sm text-brand-coral uppercase tracking-wider mb-2">96% Mood Match</p>
                    <p className="font-medium text-gray-800 mb-4">You need some serious comfort food. How about a warm, rich bowl of Ramen from ABC Restaurant?</p>
                    <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-gray-100">
                      <span className="font-bold text-sm">Potential Savings</span>
                      <span className="font-bold text-brand-green text-lg">₹75</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Why Choose CraveSense */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-5xl text-brand-dark uppercase tracking-wide mb-4">Why Choose CraveSense</h2>
          <p className="text-xl text-gray-600 font-medium max-w-2xl mx-auto">Everything you need to make the perfect dining decision.</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {FEATURES.map((feature, idx) => (
            <div key={idx} className="bg-white border border-gray-100 rounded-2xl p-6 flex flex-col items-center text-center hover:shadow-lg transition-shadow hover:border-brand-coral/30 cursor-pointer">
              <div className="w-14 h-14 rounded-full bg-brand-beige flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="font-bold text-sm">{feature.title}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Popular Food Categories */}
      <section className="py-24 bg-white border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-heading text-4xl md:text-5xl text-brand-dark uppercase tracking-wide mb-4">Popular Cravings</h2>
              <p className="text-xl text-gray-600 font-medium">Explore what others are matching with their moods.</p>
            </div>
            <button className="hidden md:flex items-center gap-2 text-brand-coral font-bold hover:underline">
              View All <ArrowRight className="w-5 h-5"/>
            </button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {CATEGORIES.map((cat, idx) => (
              <div key={idx} className="group relative rounded-2xl overflow-hidden aspect-[4/5] cursor-pointer">
                <img src={cat.image} alt={cat.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-5 w-full">
                  <h3 className="text-white font-heading text-xl uppercase tracking-wider">{cat.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Featured Restaurants */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-5xl text-brand-dark uppercase tracking-wide mb-4">Featured Spots</h2>
          <p className="text-xl text-gray-600 font-medium max-w-2xl mx-auto">Top-rated restaurants tailored to popular moods.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {RESTAURANTS.map((rest, idx) => (
            <div key={idx} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-heading text-2xl uppercase tracking-wide">{rest.name}</h3>
                  <p className="text-gray-500 font-medium text-sm">{rest.cuisine}</p>
                </div>
                <div className="flex items-center gap-1 bg-brand-beige px-2 py-1 rounded-lg">
                  <Star className="w-4 h-4 text-brand-coral fill-brand-coral" />
                  <span className="font-bold text-sm">{rest.rating}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 text-sm font-bold text-gray-600 mb-6">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4"/> {rest.time}</span>
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4"/> {rest.distance}</span>
                <span className="flex items-center gap-1"><Wallet className="w-4 h-4"/> {rest.price}</span>
              </div>
              <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                <span className="text-xs text-gray-400 font-bold uppercase tracking-wider block mb-1">Most Popular</span>
                <span className="font-bold">{rest.popular}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. Testimonials */}
      <section className="py-24 bg-brand-dark text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-4xl md:text-5xl uppercase tracking-wide mb-16 text-center">What Food Lovers Say</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial, idx) => (
              <div key={idx} className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
                <div className="flex gap-1 mb-6">
                  {[1,2,3,4,5].map(star => <Star key={star} className="w-5 h-5 text-brand-coral fill-brand-coral" />)}
                </div>
                <p className="text-lg font-medium leading-relaxed mb-8">"{testimonial.text}"</p>
                <div>
                  <p className="font-bold">{testimonial.author}</p>
                  <p className="text-sm text-gray-400">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-gray-400 mt-12 font-medium">*Sample testimonials until real customer reviews are gathered.</p>
        </div>
      </section>

      {/* 8. FAQ */}
      <section className="py-24 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-5xl text-brand-dark uppercase tracking-wide mb-4">Got Questions?</h2>
        </div>
        <div className="space-y-4">
          {FAQS.map((faq, idx) => (
            <div key={idx} className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
              <button 
                className="w-full px-6 py-5 flex justify-between items-center text-left focus:outline-none"
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
              >
                <span className="font-bold text-lg pr-4">{faq.q}</span>
                <ChevronDown className={`w-6 h-6 text-brand-coral transition-transform ${openFaq === idx ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {openFaq === idx && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-5 text-gray-600 font-medium leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </section>

      {/* 9. Final CTA */}
      <section className="py-24 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-brand-coral rounded-[3rem] p-12 md:p-20 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4"></div>
          <h2 className="font-heading text-5xl md:text-6xl text-white uppercase tracking-wide mb-8 relative z-10">
            Ready to discover your perfect meal?
          </h2>
          <div className="flex flex-col sm:flex-row justify-center gap-4 relative z-10">
            <button onClick={onGetStarted} className="px-10 py-4 bg-brand-dark text-white font-bold text-xl rounded-full shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all uppercase tracking-wide">
              Get Started
            </button>
            <button onClick={onGetStarted} className="px-10 py-4 bg-white text-brand-coral font-bold text-xl rounded-full shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all uppercase tracking-wide">
              Explore Restaurants
            </button>
          </div>
        </div>
      </section>

      {/* 10. Professional Footer */}
      <footer className="bg-brand-dark text-white pt-24 pb-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-16">
            
            <div className="md:col-span-5">
              <h2 className="font-heading text-3xl text-brand-coral uppercase tracking-wide mb-2">CraveSense</h2>
              <p className="font-bold text-lg mb-6">From Mood to Meal.</p>
              <p className="text-gray-400 font-medium leading-relaxed max-w-sm mb-8">
                CraveSense uses AI to understand your mood, recommend personalized meals, and compare prices across restaurants and food delivery platforms to help you make smarter food choices.
              </p>
              <div className="flex gap-4">
                {/* Social Icons Placeholders */}
                {['Instagram', 'X', 'LinkedIn', 'GitHub'].map((social) => (
                  <div key={social} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-brand-coral hover:border-brand-coral transition-colors cursor-pointer text-sm font-bold">
                    {social[0]}
                  </div>
                ))}
              </div>
            </div>

            <div className="md:col-span-2">
              <h4 className="font-bold text-lg mb-6 uppercase tracking-wider text-gray-400">Quick Links</h4>
              <ul className="space-y-4 font-medium">
                <li><a href="#" className="hover:text-brand-coral transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">How It Works</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Compare Prices</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Restaurants</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">FAQ</a></li>
              </ul>
            </div>

            <div className="md:col-span-2">
              <h4 className="font-bold text-lg mb-6 uppercase tracking-wider text-gray-400">Company</h4>
              <ul className="space-y-4 font-medium">
                <li><a href="#" className="hover:text-brand-coral transition-colors">About</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-brand-coral transition-colors">Terms of Service</a></li>
              </ul>
            </div>

            <div className="md:col-span-3">
              <h4 className="font-bold text-lg mb-6 uppercase tracking-wider text-gray-400">Support</h4>
              <p className="font-medium text-gray-300 mb-2">Email:</p>
              <a href="mailto:cravesensee@gmail.com" className="font-bold text-brand-coral hover:underline text-lg">cravesensee@gmail.com</a>
            </div>

          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left text-sm font-medium text-gray-500">
            <p>© 2026 CraveSense. All rights reserved.</p>
            <p className="max-w-2xl text-xs leading-relaxed">
              * Restaurant names, prices, ratings, and recommendations shown on this website may contain sample or placeholder data until connected to live restaurant and delivery services.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
