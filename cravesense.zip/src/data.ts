export const MOODS = [
    { id: 'happy', emoji: '😊', label: 'Happy', description: 'Celebrate with vibrant flavors', image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80' },
    { id: 'stressed', emoji: '😰', label: 'Stressed', description: 'Comfort food to soothe', image: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=800&q=80' },
    { id: 'energetic', emoji: '⚡', label: 'Energetic', description: 'Bold & spicy kicks', image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80' },
    { id: 'tired', emoji: '😴', label: 'Tired', description: 'Quick energy boosters', image: 'https://images.unsplash.com/photo-1517701550927-30cfcb64ac45?w=800&q=80' },
    { id: 'adventurous', emoji: '🌟', label: 'Adventurous', description: 'Exotic culinary journeys', image: 'https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&q=80' },
    { id: 'cozy', emoji: '🏡', label: 'Cozy', description: 'Warm homestyle delights', image: 'https://images.unsplash.com/photo-1541513282218-360d8dbafb5e?w=800&q=80' },
    { id: 'healthy', emoji: '🥗', label: 'Healthy', description: 'Fresh & nutritious choices', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80' },
    { id: 'indulgent', emoji: '🍰', label: 'Indulgent', description: 'Treat yourself today', image: 'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?w=800&q=80' },
    { id: 'romantic', emoji: '💕', label: 'Romantic', description: 'Perfect for date nights', image: 'https://images.unsplash.com/photo-1577906096429-f73c2c312435?w=800&q=80' },
    { id: 'nostalgic', emoji: '🕰️', label: 'Nostalgic', description: 'Childhood favorites', image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=800&q=80' }
];

export const DELIVERY_APPS = [
    { name: 'Zomato', icon: '🍽️', url: 'https://www.zomato.com/search?q=' },
    { name: 'Swiggy', icon: '🛵', url: 'https://www.swiggy.com/search?q=' },
    { name: 'Magicpin', icon: '✨', url: 'https://magicpin.in/search/?query=' },
    { name: 'Dineout', icon: '🍴', url: 'https://www.dineout.co.in/search?q=' }
];

export const QUOTES = [
    { text: "Food is not just eating energy. It's an experience.", author: "Guy Fieri" },
    { text: "One cannot think well, love well, sleep well, if one has not dined well.", author: "Virginia Woolf" },
    { text: "Let food be thy medicine and medicine be thy food.", author: "Hippocrates" },
    { text: "Life is uncertain. Eat dessert first.", author: "Ernestine Ulmer" },
    { text: "Good food is the foundation of genuine happiness.", author: "Auguste Escoffier" }
];

export const MOCK_RESULTS: Record<string, any[]> = {
    happy: [
        { name: 'Paneer Tikka Pizza', description: 'Fusion pizza with tandoori paneer & Indian spices!', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹320', Swiggy: '₹310' }, source: 'Zomato, Swiggy', tags: ['Fusion', 'Comfort', 'Spicy'], image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80' },
        { name: 'Tandoori Momos', description: 'Spicy roasted momos - street food favorite!', price: '₹120-180', offlinePrice: '₹120', deliveryPrices: { Zomato: '₹160', Swiggy: '₹170' }, source: 'Swiggy, Zomato', tags: ['Street Food', 'Spicy'], image: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=800&q=80' },
        { name: 'Kulfi Falooda', description: 'Traditional sweet dessert with kulfi & vermicelli', price: '₹80-150', offlinePrice: '₹80', deliveryPrices: { Zomato: '₹110', Swiggy: '₹115' }, source: 'Sweet shops', tags: ['Dessert', 'Traditional'], image: 'https://images.unsplash.com/photo-1563805042-7684c8a9e9cb?w=800&q=80' },
        { name: 'Loaded Nachos', description: 'Crispy tortillas loaded with cheese, salsa, and jalapenos', price: '₹200-350', offlinePrice: '₹200', deliveryPrices: { Zomato: '₹280', Swiggy: '₹270' }, source: 'Cafes', tags: ['Snack', 'Cheesy', 'Mexican'], image: 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=800&q=80' },
        { name: 'Mango Cheesecake', description: 'Creamy cheesecake topped with fresh mango glaze', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹220', Swiggy: '₹210' }, source: 'Bakeries', tags: ['Dessert', 'Sweet'], image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&q=80' },
        { name: 'Chicken Wings', description: 'Crispy fried wings tossed in sweet & spicy BBQ sauce', price: '₹300-450', offlinePrice: '₹300', deliveryPrices: { Zomato: '₹390', Swiggy: '₹380' }, source: 'Fast Food', tags: ['Non-Veg', 'Spicy', 'Appetizer'], image: 'https://images.unsplash.com/photo-1524114664604-cd8133cd67ad?w=800&q=80' }
    ],
    stressed: [
        { name: 'Dal Khichdi', description: 'Warm comfort food with rice & lentils', price: '₹100-180', offlinePrice: '₹100', deliveryPrices: { Zomato: '₹140', Swiggy: '₹145' }, source: 'Home-style restaurants', tags: ['Comfort', 'Soothing'], image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800&q=80' },
        { name: 'Butter Chicken', description: 'Creamy curry that melts stress away', price: '₹280-450', offlinePrice: '₹280', deliveryPrices: { Zomato: '₹350', Swiggy: '₹365' }, source: 'Punjabi restaurants', tags: ['Comfort', 'Classic'], image: 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=800&q=80' },
        { name: 'Mac and Cheese', description: 'Creamy, cheesy pasta bowl', price: '₹200-350', offlinePrice: '₹200', deliveryPrices: { Zomato: '₹260', Swiggy: '₹275' }, source: 'Cafes', tags: ['Comfort', 'Cheesy'], image: 'https://images.unsplash.com/photo-1543339494-b4cd4f7ba686?w=800&q=80' },
        { name: 'Margherita Pizza', description: 'Classic cheese and tomato pizza for instant comfort', price: '₹300-450', offlinePrice: '₹300', deliveryPrices: { Zomato: '₹390', Swiggy: '₹400' }, source: 'Pizzerias', tags: ['Comfort', 'Italian'], image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&q=80' },
        { name: 'Dark Chocolate Brownie', description: 'Rich, fudgy brownie to boost those endorphins', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹210', Swiggy: '₹215' }, source: 'Bakeries', tags: ['Dessert', 'Chocolate'], image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=800&q=80' }
    ],
    energetic: [
        { name: 'Schezwan Fried Rice', description: 'Bold Indo-Chinese with spicy kick', price: '₹180-280', offlinePrice: '₹180', deliveryPrices: { Zomato: '₹230', Swiggy: '₹245' }, source: 'Chinese restaurants', tags: ['Spicy', 'Indo-Chinese'], image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&q=80' },
        { name: 'Tandoori Chicken Bowl', description: 'High-protein bowl to fuel you', price: '₹220-350', offlinePrice: '₹220', deliveryPrices: { Zomato: '₹280', Swiggy: '₹290' }, source: 'Health cafes', tags: ['Protein', 'Healthy'], image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80' },
        { name: 'Spicy Chicken Tacos', description: 'Hard shell tacos filled with spicy chicken and salsa', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹310', Swiggy: '₹320' }, source: 'Mexican', tags: ['Spicy', 'Crunchy'], image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80' },
        { name: 'Cold Brew Coffee', description: 'Strong, smooth, and highly caffeinated', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹190', Swiggy: '₹200' }, source: 'Coffee Shops', tags: ['Beverage', 'Energy'], image: 'https://images.unsplash.com/photo-1461023058943-07cb124317be?w=800&q=80' }
    ],
    tired: [
        { name: 'Filter Coffee & Masala Dosa', description: 'Classic South Indian energy booster', price: '₹100-200', offlinePrice: '₹100', deliveryPrices: { Zomato: '₹140', Swiggy: '₹145' }, source: 'South Indian Cafes', tags: ['Breakfast', 'Energy'], image: 'https://images.unsplash.com/photo-1610192131652-32b005188fcc?w=800&q=80' },
        { name: 'Acai Bowl', description: 'Fresh fruits and granola to wake you up', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹320', Swiggy: '₹330' }, source: 'Health cafes', tags: ['Healthy', 'Fresh'], image: 'https://images.unsplash.com/photo-1590301157890-4810ed35a4d3?w=800&q=80' },
        { name: 'Chicken Soup', description: 'A warm, soothing broth with tender chicken and veggies', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹190', Swiggy: '₹200' }, source: 'Home-style restaurants', tags: ['Comfort', 'Warm'], image: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=800&q=80' },
        { name: 'Avocado Toast', description: 'Toasted sourdough topped with mashed avocado and a poached egg', price: '₹200-350', offlinePrice: '₹200', deliveryPrices: { Zomato: '₹250', Swiggy: '₹260' }, source: 'Cafes', tags: ['Healthy', 'Light'], image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&q=80' }
    ],
    adventurous: [
        { name: 'Sushi Platter', description: 'Assorted fresh rolls and nigiri', price: '₹600-1200', offlinePrice: '₹600', deliveryPrices: { Zomato: '₹750', Swiggy: '₹770' }, source: 'Asian restaurants', tags: ['Exotic', 'Seafood'], image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&q=80' },
        { name: 'Spicy Thai Green Curry', description: 'Authentic Thai flavors with coconut milk', price: '₹350-550', offlinePrice: '₹350', deliveryPrices: { Zomato: '₹430', Swiggy: '₹450' }, source: 'Thai restaurants', tags: ['Spicy', 'Exotic'], image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=800&q=80' },
        { name: 'Korean BBQ Beef', description: 'Thinly sliced marinated beef grilled to perfection', price: '₹400-650', offlinePrice: '₹400', deliveryPrices: { Zomato: '₹480', Swiggy: '₹500' }, source: 'Korean restaurants', tags: ['Spicy', 'Meat'], image: 'https://images.unsplash.com/photo-1580651315530-69c8e0026377?w=800&q=80' },
        { name: 'Pho', description: 'Traditional Vietnamese noodle soup with beef', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹310', Swiggy: '₹320' }, source: 'Vietnamese restaurants', tags: ['Soup', 'Comfort'], image: 'https://images.unsplash.com/photo-1582878826629-29b7ad1cb438?w=800&q=80' }
    ],
    cozy: [
        { name: 'Hot Chocolate & Brownie', description: 'Rich chocolate drink with a warm fudge brownie', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹310', Swiggy: '₹320' }, source: 'Cafes', tags: ['Sweet', 'Warm'], image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&q=80' },
        { name: 'Ramen Bowl', description: 'Warm broth with noodles and soft boiled egg', price: '₹400-600', offlinePrice: '₹400', deliveryPrices: { Zomato: '₹490', Swiggy: '₹510' }, source: 'Asian restaurants', tags: ['Comfort', 'Warm'], image: 'https://images.unsplash.com/photo-1557872943-16a5ac26437e?w=800&q=80' },
        { name: 'Tomato Soup and Grilled Cheese', description: 'The ultimate rainy day comfort combo', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹190', Swiggy: '₹200' }, source: 'Cafes', tags: ['Comfort', 'Warm', 'Classic'], image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&q=80' },
        { name: 'Cinnamon Roll', description: 'Warm, gooey, and topped with cream cheese frosting', price: '₹100-200', offlinePrice: '₹100', deliveryPrices: { Zomato: '₹140', Swiggy: '₹150' }, source: 'Bakeries', tags: ['Sweet', 'Comfort'], image: 'https://images.unsplash.com/photo-1509365465994-3e580456ccbe?w=800&q=80' }
    ],
    healthy: [
        { name: 'Quinoa Salad Bowl', description: 'Fresh greens, roasted veggies & light dressing', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹310', Swiggy: '₹330' }, source: 'Salad Bars', tags: ['Fresh', 'Light'], image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80' },
        { name: 'Grilled Salmon', description: 'Rich in omega-3 with steamed asparagus', price: '₹600-900', offlinePrice: '₹600', deliveryPrices: { Zomato: '₹750', Swiggy: '₹770' }, source: 'Fine Dining', tags: ['Protein', 'Nutritious'], image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&q=80' },
        { name: 'Vegan Buddha Bowl', description: 'Packed with lentils, chickpeas, and fresh greens', price: '₹250-400', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹310', Swiggy: '₹320' }, source: 'Health cafes', tags: ['Vegan', 'Healthy'], image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&q=80' },
        { name: 'Green Smoothie', description: 'Spinach, apple, and ginger for a healthy detox', price: '₹120-200', offlinePrice: '₹120', deliveryPrices: { Zomato: '₹160', Swiggy: '₹170' }, source: 'Juice Bars', tags: ['Healthy', 'Beverage'], image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?w=800&q=80' }
    ],
    indulgent: [
        { name: 'Loaded Cheeseburger', description: 'Double patty with extra cheese and bacon', price: '₹350-600', offlinePrice: '₹350', deliveryPrices: { Zomato: '₹430', Swiggy: '₹450' }, source: 'Burger Joints', tags: ['Heavy', 'Treat'], image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80' },
        { name: 'Triple Chocolate Cake', description: 'Decadent layers of chocolate fudge', price: '₹250-450', offlinePrice: '₹250', deliveryPrices: { Zomato: '₹320', Swiggy: '₹340' }, source: 'Bakeries', tags: ['Dessert', 'Rich'], image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80' },
        { name: 'Loaded Fries', description: 'French fries topped with melted cheese, bacon, and jalapenos', price: '₹150-250', offlinePrice: '₹150', deliveryPrices: { Zomato: '₹200', Swiggy: '₹210' }, source: 'Fast Food', tags: ['Snack', 'Heavy'], image: 'https://images.unsplash.com/photo-1585553616435-2dc0a54e271d?w=800&q=80' },
        { name: 'Milkshake Supreme', description: 'Thick shake topped with whipped cream and brownies', price: '₹180-300', offlinePrice: '₹180', deliveryPrices: { Zomato: '₹230', Swiggy: '₹240' }, source: 'Dessert Parlors', tags: ['Sweet', 'Indulgent'], image: 'https://images.unsplash.com/photo-1572490122747-3968b75bf699?w=800&q=80' }
    ],
    romantic: [
        { name: 'Truffle Mushroom Risotto', description: 'Creamy Italian rice with earthy truffle oil', price: '₹500-800', offlinePrice: '₹500', deliveryPrices: { Zomato: '₹610', Swiggy: '₹630' }, source: 'Italian Restaurants', tags: ['Elegant', 'Italian'], image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=800&q=80' },
        { name: 'Steak Frites', description: 'Perfectly seared steak with crispy fries', price: '₹800-1500', offlinePrice: '₹800', deliveryPrices: { Zomato: '₹980', Swiggy: '₹1020' }, source: 'Steakhouses', tags: ['Classic', 'Dinner'], image: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=800&q=80' },
        { name: 'Oysters on the Half Shell', description: 'Fresh oysters served with lemon and mignonette', price: '₹600-1000', offlinePrice: '₹600', deliveryPrices: { Zomato: '₹750', Swiggy: '₹780' }, source: 'Seafood Restaurants', tags: ['Elegant', 'Seafood'], image: 'https://images.unsplash.com/photo-1594968364653-f726887532f1?w=800&q=80' },
        { name: 'Chocolate Fondue', description: 'Melted chocolate with fresh fruit and marshmallows', price: '₹300-500', offlinePrice: '₹300', deliveryPrices: { Zomato: '₹380', Swiggy: '₹400' }, source: 'Dessert Parlors', tags: ['Sweet', 'Sharing'], image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=800&q=80' }
    ],
    nostalgic: [
        { name: 'Aloo Paratha with Butter', description: 'Stuffed flatbread just like mom makes', price: '₹80-150', offlinePrice: '₹80', deliveryPrices: { Zomato: '₹120', Swiggy: '₹130' }, source: 'Dhabas', tags: ['Home-style', 'Breakfast'], image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80' },
        { name: 'Maggi Noodles', description: 'The ultimate childhood midnight snack', price: '₹50-100', offlinePrice: '₹50', deliveryPrices: { Zomato: '₹80', Swiggy: '₹85' }, source: 'Cafes', tags: ['Snack', 'Quick'], image: 'https://images.unsplash.com/photo-1612929633738-8fe01f7c8102?w=800&q=80' },
        { name: 'Macaroni Salad', description: 'Classic creamy macaroni salad like at a family picnic', price: '₹100-150', offlinePrice: '₹100', deliveryPrices: { Zomato: '₹130', Swiggy: '₹140' }, source: 'Delis', tags: ['Classic', 'Comfort'], image: 'https://images.unsplash.com/photo-1543339494-b4cd4f7ba686?w=800&q=80' },
        { name: 'Grilled Cheese Sandwich', description: 'Simple, buttery, and perfectly melted cheese', price: '₹80-120', offlinePrice: '₹80', deliveryPrices: { Zomato: '₹110', Swiggy: '₹120' }, source: 'Cafes', tags: ['Comfort', 'Classic'], image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&q=80' }
    ]
};
