import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, MapPin, IndianRupee, GraduationCap, Search, Sparkles, ChefHat } from 'lucide-react';
import { MOODS, DELIVERY_APPS, QUOTES, MOCK_RESULTS } from './data';
import { LandingSections } from './components/LandingSections';

export default function App() {
  const [step, setStep] = useState<'landing' | 'input' | 'loading' | 'results'>('landing');
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [location, setLocation] = useState('');
  const [budget, setBudget] = useState('');
  const [isStudent, setIsStudent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [error, setError] = useState('');
  
  const [isListening, setIsListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<{title: string, text: string} | null>(null);
  const [currentQuote, setCurrentQuote] = useState(QUOTES[0]);
  
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const quoteInterval = setInterval(() => {
      setCurrentQuote(QUOTES[Math.floor(Math.random() * QUOTES.length)]);
    }, 8000);

    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-IN';

        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript.toLowerCase();
          handleVoiceCommand(transcript);
        };

        recognitionRef.current.onerror = (event: any) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
          setVoiceStatus({ title: 'Error', text: 'Could not understand. Please try again.' });
          setTimeout(() => setVoiceStatus(null), 3000);
        };

        recognitionRef.current.onend = () => {
          setIsListening(false);
        };
      }
    }

    return () => clearInterval(quoteInterval);
  }, [location, selectedMood]); // Add dependencies needed by handleVoiceCommand

  const handleVoiceCommand = (transcript: string) => {
    setVoiceStatus({ title: 'Heard', text: `"${transcript}"` });

    const moodKeywords: Record<string, string[]> = {
      happy: ['happy', 'cheerful', 'joyful', 'excited'],
      stressed: ['stressed', 'anxious', 'worried', 'overwhelmed'],
      energetic: ['energetic', 'active', 'pumped', 'hyper'],
      tired: ['tired', 'exhausted', 'sleepy', 'weary'],
      adventurous: ['adventurous', 'daring', 'bold', 'experimental'],
      cozy: ['cozy', 'comfortable', 'relaxed', 'chill'],
      healthy: ['healthy', 'fit', 'nutritious', 'clean'],
      indulgent: ['indulgent', 'treat', 'splurge', 'decadent'],
      romantic: ['romantic', 'date', 'love', 'couple'],
      nostalgic: ['nostalgic', 'childhood', 'memories', 'classic']
    };

    let moodFound = false;
    for (const [moodId, keywords] of Object.entries(moodKeywords)) {
      if (keywords.some(keyword => transcript.includes(keyword))) {
        setSelectedMood(moodId);
        const moodLabel = MOODS.find(m => m.id === moodId)?.label;
        setVoiceStatus({ title: 'Perfect!', text: `Set mood to ${moodLabel}` });
        speak(`Great choice! I've set your mood to ${moodLabel}`);
        moodFound = true;
        setTimeout(() => setVoiceStatus(null), 3000);
        break;
      }
    }

    if (transcript.includes('location') || transcript.includes('near') || transcript.includes('in')) {
      const locationMatch = transcript.match(/(?:near|in|at)\s+(.+)/);
      if (locationMatch) {
        setLocation(locationMatch[1]);
        speak(`Location set to ${locationMatch[1]}`);
      }
    }

    if (transcript.includes('student') || transcript.includes('discount')) {
      setIsStudent(true);
      speak('Student discounts enabled!');
    }

    if (transcript.includes('find') || transcript.includes('search') || transcript.includes('recommend') || transcript.includes('show')) {
      if ((moodFound || selectedMood) && location) {
        speak('Finding your perfect food match now');
        handleSubmit();
      } else {
        speak('Please tell me your mood and location first');
      }
    }

    if (!moodFound) {
      setTimeout(() => setVoiceStatus(null), 3000);
    }
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.1;
      utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleVoice = () => {
    if (!recognitionRef.current) {
      alert('Voice recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      setVoiceStatus(null);
    } else {
      setIsListening(true);
      setVoiceStatus({ title: 'Listening...', text: 'Say "I feel happy" or "Find food near Indiranagar"' });
      speak('Hello! I am your food assistant. How can I help you today?');
      recognitionRef.current.start();
    }
  };

  const handleSubmit = async () => {
    if (!selectedMood || !location) {
      setError('Please select a mood and enter your location');
      return;
    }

    setLoading(true);
    setError('');
    setStep('loading');

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setResults(MOCK_RESULTS[selectedMood] || MOCK_RESULTS.happy);
    setStep('results');
    speak('I found perfect recommendations for you!');
    setLoading(false);
  };

  const generateDeliveryLinks = (foodName: string, loc: string) => {
    const searchQuery = encodeURIComponent(`${foodName} ${loc}`);
    return DELIVERY_APPS.map(app => ({
      ...app,
      fullUrl: `${app.url}${searchQuery}`
    }));
  };

  return (
    <div className="min-h-screen bg-brand-beige font-sans text-brand-dark relative overflow-x-hidden selection:bg-brand-coral/30">
      {/* Decorative Food Background Images */}
      <AnimatePresence>
        {(step === 'landing' || step === 'input') && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute top-0 left-0 w-full h-[100vh] pointer-events-none z-0 overflow-hidden"
          >
            <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80" alt="food" className="absolute top-[10%] left-[10%] w-64 h-auto rounded-3xl shadow-2xl transform -rotate-3 object-cover aspect-square" crossOrigin="anonymous" />
            <img src="https://images.unsplash.com/photo-1584473457406-6240486418e9?auto=format&fit=crop&w=400&q=80" alt="drink" className="absolute top-[25%] left-[30%] w-24 h-auto rounded-full shadow-xl transform rotate-12 object-cover aspect-[1/3]" crossOrigin="anonymous" />
            <img src="https://images.unsplash.com/photo-1576402187878-974f70c890a5?auto=format&fit=crop&w=600&q=80" alt="container" className="absolute top-[15%] right-[20%] w-72 h-auto rounded-3xl shadow-2xl transform rotate-2 object-cover aspect-video" crossOrigin="anonymous" />
            <img src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80" alt="bowl" className="absolute top-[45%] right-[15%] w-48 h-auto rounded-[2.5rem] shadow-2xl transform -rotate-6 object-cover aspect-square" crossOrigin="anonymous" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <nav className="relative z-20 flex justify-between items-center px-6 md:px-12 py-6 max-w-[1600px] mx-auto">
        <div className="hidden md:flex gap-8 font-bold text-sm tracking-wide">
          <span className="cursor-pointer hover:text-brand-coral transition-colors">How it works</span>
          <span className="cursor-pointer hover:text-brand-coral transition-colors">Quality</span>
          <span className="cursor-pointer hover:text-brand-coral transition-colors">Community</span>
        </div>
        
        <h1 className="absolute left-1/2 top-[75%] -translate-x-1/2 -translate-y-1/2 font-heading text-4xl md:text-5xl text-brand-coral uppercase tracking-wide cursor-pointer hover:scale-105 transition-transform font-bold">
          CraveSense
        </h1>

        <div className="hidden md:flex gap-6 items-center font-bold text-sm">
          <button onClick={() => setStep('input')} className="cursor-pointer hover:text-brand-coral transition-colors">Log In</button>
          <button onClick={() => setStep('input')} className="border-2 border-brand-coral text-brand-coral px-5 py-2 rounded-full hover:bg-brand-coral hover:text-white transition-colors">
            Create Account
          </button>
        </div>
      </nav>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 pb-12 pt-6 relative z-10 flex flex-col min-h-[80vh]">
        
        {/* Dynamic Quote (Hidden in input step for cleaner hero look, shown in loading/results) */}
        <AnimatePresence>
          {step !== 'input' && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="max-w-3xl mx-auto bg-white/10 backdrop-blur-md rounded-[2rem] p-8 shadow-sm border border-white/20 mb-12 text-center"
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentQuote.text}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <p className="font-sans text-xl md:text-2xl font-bold text-brand-dark mb-2">
                    "{currentQuote.text}"
                  </p>
                  <p className="text-brand-coral font-bold tracking-wider uppercase text-xs">
                    — {currentQuote.author}
                  </p>
                </motion.div>
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <AnimatePresence mode="wait">
          
          {step === 'landing' && (
            <motion.div
              key="landing-step"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="flex-grow flex flex-col justify-end pb-12 relative z-10 h-[70vh]"
            >
              <div className="flex flex-col lg:flex-row lg:items-end justify-between w-full mt-auto gap-8">
                <div className="max-w-2xl">
                  <h2 className="font-heading text-6xl md:text-[5.5rem] leading-[0.95] text-brand-white uppercase drop-shadow-[0_4px_8px_rgba(0,0,0,0.15)]">
                    Satisfy Your<br/>Cravings.
                  </h2>
                </div>
                <div className="flex flex-col gap-4 w-full lg:max-w-md lg:pb-4">
                  <p className="text-xl md:text-2xl font-medium text-brand-white drop-shadow-md">
                    Gourmet food tailored to your mood.
                  </p>
                  <div className="flex w-full bg-white rounded-full p-2 shadow-xl items-center border border-gray-100">
                    <div className="flex-grow px-4 flex items-center">
                      <MapPin className="w-5 h-5 text-gray-400 mr-2" />
                      <input 
                        type="text" 
                        placeholder="Location" 
                        className="w-full bg-transparent border-none outline-none font-medium text-brand-dark placeholder-gray-400"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                      />
                    </div>
                    <button onClick={() => setStep('input')} className="px-8 py-3 bg-brand-coral text-white font-bold rounded-full hover:bg-[#E05C43] transition-colors whitespace-nowrap">
                      Start Dining &rarr;
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'input' && (
            <motion.div
              key="input-step"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="flex-grow flex flex-col justify-center pb-8"
            >
              {/* The "Form" Section */}
              <div className="bg-brand-white rounded-[2.5rem] p-8 md:p-10 shadow-xl border border-gray-100 relative z-10 max-w-5xl mx-auto w-full mt-10">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-1 bg-brand-dark rounded-full"></div>
                  <h3 className="font-heading text-2xl uppercase tracking-wide text-brand-dark">How are you feeling?</h3>
                </div>

                {/* Mood Grid with Images */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-12">
                {MOODS.map(mood => (
                  <button
                    key={mood.id}
                    onClick={() => setSelectedMood(mood.id)}
                    className={`group relative overflow-hidden rounded-[2rem] transition-all duration-300 focus:outline-none
                      ${selectedMood === mood.id 
                        ? 'ring-4 ring-brand-coral scale-105 shadow-lg' 
                        : 'hover:scale-105 hover:shadow-md border border-gray-100'}`}
                  >
                    <div className="aspect-[4/5] relative bg-gray-50">
                      <img 
                        src={mood.image} 
                        alt={mood.label} 
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        crossOrigin="anonymous"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                      
                      <div className="absolute inset-x-0 bottom-0 p-4 text-left">
                        <span className="text-3xl mb-2 block filter drop-shadow-md">{mood.emoji}</span>
                        <h3 className="text-white font-bold text-lg tracking-wide">{mood.label}</h3>
                        <p className="text-white/80 text-xs mt-1 line-clamp-2 leading-tight">{mood.description}</p>
                      </div>
                      
                      {selectedMood === mood.id && (
                        <div className="absolute inset-0 border-4 border-brand-coral rounded-[2rem] z-10" />
                      )}
                    </div>
                  </button>
                ))}
              </div>

              {/* Input Fields (Sleek Inline Design) */}
              <div className="flex flex-col lg:flex-row gap-4 items-center">
                <div className="flex-grow w-full bg-gray-50 border border-gray-200 rounded-full flex flex-col md:flex-row p-2 shadow-sm focus-within:ring-2 focus-within:ring-brand-coral/50 transition-all">
                  <div className="flex-1 flex items-center px-4 py-2 border-b md:border-b-0 md:border-r border-gray-200">
                    <MapPin className="w-5 h-5 text-gray-400 mr-3 shrink-0" />
                    <input
                      type="text"
                      className="w-full bg-transparent border-none outline-none text-lg font-medium placeholder-gray-400 text-brand-dark"
                      placeholder="Delivery Location..."
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                  </div>
                  <div className="flex-1 flex items-center px-4 py-2">
                    <IndianRupee className="w-5 h-5 text-gray-400 mr-3 shrink-0" />
                    <input
                      type="text"
                      className="w-full bg-transparent border-none outline-none text-lg font-medium placeholder-gray-400 text-brand-dark"
                      placeholder="Budget (Optional)"
                      value={budget}
                      onChange={(e) => setBudget(e.target.value)}
                    />
                  </div>
                </div>

                <div className="w-full lg:w-auto flex items-center gap-4">
                  <label className="flex items-center justify-center w-14 h-14 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full cursor-pointer transition-colors" title="Student Discount">
                    <input type="checkbox" className="sr-only peer" checked={isStudent} onChange={(e) => setIsStudent(e.target.checked)} />
                    <GraduationCap className={`w-6 h-6 transition-colors ${isStudent ? 'text-brand-coral' : 'text-gray-400'}`} />
                  </label>

                  <button 
                    onClick={handleSubmit}
                    disabled={!selectedMood || !location}
                    className="flex-grow lg:flex-grow-0 px-8 h-14 bg-brand-coral text-white font-bold text-lg rounded-full shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:-translate-y-1 flex items-center justify-center gap-3 whitespace-nowrap"
                  >
                    Find Food &rarr;
                  </button>
                </div>
              </div>

              {error && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} 
                  className="mt-6 p-4 bg-red-50 text-red-600 rounded-2xl border border-red-100 flex items-center gap-3 text-sm font-bold"
                >
                  <span className="text-xl">⚠️</span> {error}
                </motion.div>
              )}
              </div>
            </motion.div>
          )}

          {step === 'loading' && (
            <motion.div
              key="loading-step"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-32"
            >
              <div className="relative w-24 h-24 mb-8">
                <div className="absolute inset-0 border-4 border-gray-200 rounded-full" />
                <div className="absolute inset-0 border-4 border-brand-coral border-t-transparent rounded-full animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center text-3xl">
                  🍽️
                </div>
              </div>
              <h3 className="font-heading text-4xl font-normal text-brand-dark uppercase tracking-wide">Curating your menu...</h3>
              <p className="text-gray-500 mt-2 text-lg font-medium">Finding the best matches for your mood</p>
            </motion.div>
          )}

          {step === 'results' && (
            <motion.div
              key="results-step"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-5xl mx-auto"
            >
              <div className="flex flex-col md:flex-row items-center justify-between mb-10 text-center md:text-left gap-4">
                <div>
                  <h2 className="font-heading text-4xl md:text-5xl font-normal text-brand-dark uppercase tracking-wide flex items-center justify-center md:justify-start gap-3">
                    <Sparkles className="w-8 h-8 text-brand-coral" />
                    Your Curated Menu
                  </h2>
                  <p className="text-gray-500 text-lg mt-2 font-medium">Perfect matches for a {MOODS.find(m => m.id === selectedMood)?.label} mood in {location}</p>
                </div>
                <button 
                  onClick={() => { setStep('input'); setResults([]); }}
                  className="px-6 py-3 bg-white border border-gray-200 hover:border-brand-coral rounded-full font-bold text-brand-dark hover:text-brand-coral transition-colors shadow-sm"
                >
                  Change Cravings
                </button>
              </div>

              <div className="grid gap-8">
                {results.map((result, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-[2.5rem] overflow-hidden shadow-sm border border-gray-100 flex flex-col md:flex-row group hover:shadow-xl transition-shadow duration-500"
                  >
                    <div className="md:w-2/5 relative h-64 md:h-auto overflow-hidden">
                      <img 
                        src={result.image} 
                        alt={result.name}
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        crossOrigin="anonymous"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-4 left-4">
                        <span className="px-4 py-2 bg-white/90 backdrop-blur text-brand-dark font-bold rounded-full text-sm shadow-lg border border-white/20">
                          {result.price}
                        </span>
                      </div>
                    </div>
                    
                    <div className="p-8 md:w-3/5 flex flex-col">
                      <h3 className="font-heading text-3xl font-normal text-brand-dark mb-3 uppercase tracking-wide">{result.name}</h3>
                      <p className="text-gray-600 text-lg mb-6 leading-relaxed flex-grow font-medium">{result.description}</p>
                      
                      <div className="flex items-center gap-2 text-gray-600 mb-6 bg-gray-50 p-3 rounded-2xl w-max border border-gray-100">
                        <MapPin className="w-4 h-4 text-brand-coral" />
                        <span className="text-sm font-bold">Available at: {result.source}</span>
                      </div>

                      {result.offlinePrice && result.deliveryPrices && (
                        <div className="bg-brand-beige/30 border border-brand-beige rounded-2xl p-4 mb-6">
                          <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Price Comparison</h4>
                          <div className="flex flex-wrap gap-6 items-center">
                            <div className="flex flex-col">
                              <span className="text-xs text-brand-coral font-bold uppercase">Offline</span>
                              <span className="text-xl font-bold text-brand-green">{result.offlinePrice}</span>
                            </div>
                            {Object.entries(result.deliveryPrices).map(([app, price]) => (
                              <div key={app} className="flex flex-col border-l border-gray-200 pl-6">
                                <span className="text-xs text-gray-500 font-medium">{app}</span>
                                <span className="text-lg font-bold text-gray-700">{price as string}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex flex-wrap gap-2 mb-8">
                        {result.tags.map((tag: string, i: number) => (
                          <span key={i} className="px-4 py-1.5 bg-gray-100 text-brand-dark rounded-full text-sm font-bold">
                            {tag}
                          </span>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 border-t border-gray-100 pt-6">
                        {generateDeliveryLinks(result.name, location).map((app, i) => (
                          <a 
                            key={i} 
                            href={app.fullUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex flex-col items-center justify-center p-3 rounded-2xl border border-gray-100 hover:border-brand-coral hover:bg-brand-beige transition-colors gap-2 group/btn"
                          >
                            <span className="text-2xl group-hover/btn:scale-110 transition-transform">{app.icon}</span>
                            <span className="text-sm font-bold text-gray-600 group-hover/btn:text-brand-coral">{app.name}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {step === 'landing' && (
        <LandingSections onGetStarted={() => setStep('input')} />
      )}

      {/* Floating Voice Button */}
      <button 
        onClick={toggleVoice}
        className={`fixed bottom-8 right-8 w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center text-white shadow-xl z-50 transition-all duration-300 hover:scale-110
          ${isListening 
            ? 'bg-brand-green animate-pulse shadow-lg' 
            : 'bg-brand-dark shadow-lg'}`}
      >
        {isListening ? <Mic className="w-8 h-8 md:w-10 md:h-10 animate-bounce" /> : <MicOff className="w-7 h-7 md:w-8 md:h-8" />}
      </button>

      {/* Voice Status Toast */}
      <AnimatePresence>
        {voiceStatus && (
          <motion.div 
            initial={{ opacity: 0, x: 50, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 50, scale: 0.9 }}
            className="fixed bottom-28 md:bottom-32 right-8 bg-brand-dark text-white rounded-2xl p-5 shadow-2xl z-40 max-w-[300px]"
          >
            <h4 className="font-bold text-brand-coral text-sm uppercase tracking-wider mb-1">{voiceStatus.title}</h4>
            <p className="text-gray-200 font-medium">{voiceStatus.text}</p>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
